package controller;

import java.time.LocalDate;
import java.time.Month;

import dao.WalletRepository;
import dao.WalletRepositoryImpl;
import dto.Wallet;
import exception.WalletException;
import service.WalletService;
import service.WalletServiceImpl;

public class WalletController {

	public static void main(String[] args) throws WalletException {
//		WalletRepository walletrepository = new WalletRepositoryImpl();
		WalletService  walletService = new WalletServiceImpl();
		Wallet wallet = new Wallet(1,"mukesh",4000.0,"pass", null);
		boolean isadded = walletService.createWallet(wallet);
		System.out.println("wallet details added- " + isadded);
//		Wallet wallet = walletService.createWallet(1,"suresh",1000.0,"pass","2019-08-16");
//        Wallet wallet = walletService.getWalletById(2);
//        System.out.println(wallet);
		
//		Wallet wallet = new Wallet(7,"mukesh",4000.0,"pass",null);
//		Boolean isdeleted = walletrepository.deleteWallet(wallet);
//		System.out.println("wallet deleted " + isdeleted);
//		LocalDate x = LocalDate.now(); 
//		Wallet wallet = new Wallet(2,"pookhesh",3000.0,"pass",null);
//		wallet = walletrepository.updateWallet(wallet);
//		System.out.println(wallet);
//		Boolean Authentication = walletService.login(1, "pass");
//		if(Authentication) {
//			System.out.println("USER IS AUTHORISED :"+ Authentication);
//		}
//		
//		Double y =walletservice.addFundsToWallet(3, 5000.0);
//		System.out.println(y);
//		Boolean fundtransfer = walletservice.fundTransfer(1, 2, 100.0);
//		System.out.println("FUND HAS TRANFERED" + fundtransfer);
		
		
	
		
		
		
		
	}

}

