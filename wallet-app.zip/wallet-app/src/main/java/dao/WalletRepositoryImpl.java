package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


import dto.Wallet;

import exception.WalletException;

public class WalletRepositoryImpl implements WalletRepository{

	public Boolean addWallet(Wallet wallet) throws WalletException {
		 Connection connection = DaoUtility.getConnection();
	
			Boolean isRecordUpdated=false;
			try {
				PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO `wallet`.`walletdata` (`id`, `name`, `balance`, `creation _date`, `password`) VALUES(?,?,?,?,?)");
				
				preparedStatement.setInt(1, wallet.getId());
				preparedStatement.setString(2, wallet.getName());
				preparedStatement.setDouble(3, wallet.getBalance());
				
				preparedStatement.setObject(4,wallet.getCreationDate());
				preparedStatement.setString(5, wallet.getPassword());
			
				
				
				if(preparedStatement.executeUpdate()>0) {
					isRecordUpdated = true; 
				}
				else {
					throw new WalletException("Wallet not found for id:");
				}
				
			}catch(SQLException e) {
				System.out.println("ye bhi");
				System.out.println(e.getMessage());
				
			}
			
			return isRecordUpdated;
		 
		
	}

	public Wallet getWalletById(Integer id) throws WalletException {
		
         Connection connection = DaoUtility.getConnection();
	    Wallet wallet = null;
	    try {
	    	PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM walletdata  WHERE id = ?");
	    	preparedStatement.setInt(1, id);
ResultSet resultSet = preparedStatement.executeQuery();
			
			if(resultSet.next())
			{
				wallet = new Wallet(resultSet.getInt("id"),resultSet.getString("name"),resultSet.getDouble("balance"),resultSet.getString("password"),resultSet.getDate("creation _date").toLocalDate());
			}
			else
			{
				throw new WalletException("Wallet not found for id:"+id);
			}

	    	
	    }catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
     
		
		
		return wallet;
	}

	public Wallet updateWallet(Wallet wallet) throws WalletException {
		Connection connection = DaoUtility.getConnection();
		Boolean isRecordUpdated=false;
		try {
			PreparedStatement preparedStatement = connection.prepareStatement("UPDATE `wallet`.`walletdata` SET `name` = ?, `balance` = ?, `creation _date` = ?, `password` = ? WHERE (`id` = ?)");
			
			preparedStatement.setString(1, wallet.getName());
			preparedStatement.setDouble(2, wallet.getBalance());
			preparedStatement.setObject(3, wallet.getCreationDate());
			preparedStatement.setString(4, wallet.getPassword());
			preparedStatement.setInt(5, wallet.getId());
			
			if(preparedStatement.executeUpdate()>0) {
				isRecordUpdated = true; 
			}
			else {
			//	UPDATE `wallet`.`walletdata` SET `name` = 'suresh2', `balance` = '1001', `creation _date` = '2022-07-12', `password` = 'pass2' WHERE (`id` = '6');
			}
			
		}catch(SQLException e) {
			System.out.println("ye chala");
			System.out.println(e.getMessage());
			
		}
		
		return wallet;
		
	}

	public Boolean deleteWallet(Wallet wallet) throws WalletException {
		Connection connection = DaoUtility.getConnection();
		Integer id = wallet.getId();
		Boolean isRecordDeleted=false;
		try {
			PreparedStatement preparedStatement = connection.prepareStatement("delete from walletdata where id =?");
			preparedStatement.setInt(1, id);
		//	preparedStatement.setString(2, employee.getName());
			//preparedStatement.setDouble(3, employee.getSalary());
			if(preparedStatement.executeUpdate()>0) {
				isRecordDeleted = true; 
			}
			else {
				// handle exception
			}
			
		}catch(SQLException e) {
			
			System.out.println(e.getMessage());
			
		}
		
		return isRecordDeleted;
		
	}

}
