package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DaoUtility {

	public static Connection getConnection() {
		Connection connection = null;
		try {
			connection = DriverManager.getConnection("jdbc:mysql://localhost/demo?" + "user=root&password=root");
			System.out.println("Successful Connection to Mysql ");
			
		} catch (SQLException e) {
			System.out.println("SQLException: " + e.getMessage());

		}
		
		return connection;

	}
}

	

