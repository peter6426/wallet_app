package dao;

import dto.Wallet;
import exception.WalletException;

public interface WalletRepository {
	Boolean addWallet(Wallet wallet) throws WalletException;

	Wallet getWalletById(Integer walletId) throws WalletException;

	Wallet updateWallet(Wallet wallet) throws WalletException;

	Boolean deleteWallet(Wallet wallet) throws WalletException;

}
