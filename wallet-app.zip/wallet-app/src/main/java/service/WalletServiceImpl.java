package service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import dao.DaoUtility;
import dao.WalletRepository;
import dao.WalletRepositoryImpl;
import dto.Wallet;
import exception.WalletException;

public class WalletServiceImpl implements WalletService{
	private WalletRepository walletrepo = new WalletRepositoryImpl();

	public Boolean createWallet(Wallet wallet) throws WalletException {
		
		return this.walletrepo.addWallet(wallet);
	}

	
	
	public Wallet getWalletById(Integer id) throws WalletException {
	     
			return this.walletrepo.getWalletById(id);
		
	}

	
	
	public Double addFundsToWallet(Integer walletId, Double amount) throws WalletException {
		 Connection connection = DaoUtility.getConnection();
		 Integer id = walletId;
		 Wallet wallet = null;
		 try {
			 PreparedStatement preparedStatement2 = connection.prepareStatement("SELECT * FROM walletdata  WHERE id = ?");
		    	preparedStatement2.setInt(1, id);
		    	ResultSet resultSet = preparedStatement2.executeQuery();
		    	if(resultSet.next())
				{
					wallet = new Wallet(resultSet.getInt("id"),resultSet.getString("name"),resultSet.getDouble("balance"),resultSet.getString("password"),resultSet.getDate("creation _date").toLocalDate());
				}
			PreparedStatement preparedStatement = connection.prepareStatement("UPDATE `wallet`.`walletdata` SET `balance` = ? WHERE (`id` = ?)");
			preparedStatement.setDouble(1, wallet.getBalance()+amount);
			preparedStatement.setInt(2, wallet.getId());
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return wallet.getBalance()+amount;
	}

	public Boolean fundTransfer(Integer fromWalletId, Integer toWalletId, Double amount) throws WalletException {
		Boolean fundtransfer = true;
	     Wallet wallet2 = walletrepo.getWalletById(toWalletId);
	     Wallet wallet1 = walletrepo.getWalletById(fromWalletId);
	     wallet2.setBalance(wallet2.getBalance()+amount);
	     wallet1.setBalance(wallet1.getBalance()-amount);
	     Double x = wallet1.getBalance();
	     walletrepo.updateWallet(wallet1);
	     walletrepo.updateWallet(wallet2);
	     Wallet wallet3 = walletrepo.getWalletById(fromWalletId);
	     System.out.println(wallet3.getBalance());
	     System.out.println(x);
	     if(wallet3.getBalance().equals(x)) {
	    	
	    	 fundtransfer=true;
	     }
	     else {
	    	 throw new WalletException("some erroe occured");
	     }
	     
		return fundtransfer;
	}

	public Boolean login(Integer walletId, String password) throws WalletException {
         
		Boolean isAuthorised=false;
		Wallet wallet = walletrepo.getWalletById(walletId);
		String x = wallet.getPassword();
		if(x.equals(password)) {
			isAuthorised=true;
		}
		else {
			throw new WalletException("User is not Authorised");
		}
		return isAuthorised;
	}

}
