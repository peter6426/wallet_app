package com.wallet.testapp;



import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Assumptions;
import org.junit.jupiter.api.Test;

import dao.WalletRepository;
import dao.WalletRepositoryImpl;
import dto.Wallet;
import exception.WalletException;
import service.WalletService;
import service.WalletServiceImpl;

public class WalletTest {

	WalletService walletservice = new WalletServiceImpl();
	WalletRepository walletrepository = new WalletRepositoryImpl();
	
	@Test
	public void testcreatewallet() throws WalletException {
	   Assumptions.assumeTrue(walletservice !=null);
		Boolean actual = walletservice.createWallet(new Wallet(9,"surender",6000.0,"pass1",null));
		Assertions.assertEquals(true, actual);
		Assertions.assertEquals(true, walletrepository.deleteWallet(new Wallet(9,"surender",6000.0,"pass1",null)));
		
		
	}
 @Test
public void  testwalletUpdate() throws WalletException {
	 Wallet wallet = walletservice.getWalletById(2);
	 Assumptions.assumeTrue(wallet !=null);
	 wallet.setName("new pookesh");
	 Assertions.assertEquals("new pookesh", walletrepository.updateWallet(wallet).getName());
 }
	
 @Test
 public void testwalletById() throws WalletException {
	 Assumptions.assumeTrue(walletservice != null);
	 Wallet wallet = walletservice.getWalletById(2);
	 Assertions.assertEquals(2, wallet.getId());
			 
 
 }
 
 @Test
 public void testwalletdelete() throws WalletException {
	 Assumptions.assumeTrue(walletservice != null);
	 Wallet wallet = walletservice.getWalletById(3); 
	 Assertions.assertEquals(true, walletrepository.deleteWallet(wallet));
	 Assertions.assertEquals(true, walletrepository.addWallet(wallet));
	 
 }
 
 @Test
 public void testaddFundsToWallet() throws WalletException {
	 Assumptions.assumeTrue(walletservice != null);
	 Wallet wallet = walletservice.getWalletById(3);
	 double x = wallet.getBalance();
	// Assertions.assertEquals(true, walletservice.addFundsToWallet(3, 500.0));
	 walletservice.addFundsToWallet(3, 500.0);
	 wallet = null;
	 Wallet wallet2 = walletservice.getWalletById(3);
	 Assertions.assertEquals(x+500.0, wallet2.getBalance() );
	 
	 
	 
	 
 }
 
	
}
